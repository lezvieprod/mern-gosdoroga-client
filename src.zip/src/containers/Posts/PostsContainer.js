import React from 'react';
import Posts from '../../components/Posts/Posts';

const PostsContainer = () => {

  
  return (
    <Posts/>
  );
}

export default PostsContainer;
