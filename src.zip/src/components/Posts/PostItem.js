import { Box } from '@chakra-ui/react';
import React from 'react';

const PostItem = () => {
  return (
    <Box>
      PostItem
    </Box>
  );
}

export default PostItem;
